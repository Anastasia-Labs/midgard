import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import crypto from 'node:crypto';import {performance} from 'node:perf_hooks';import {createRequire} from 'node:module';import {pathToFileURL,fileURLToPath} from 'node:url';
const base=path.dirname(fileURLToPath(import.meta.url));const require=createRequire(import.meta.url);
const [label,target,folder]=process.argv.slice(2);assert(['node','browser'].includes(target));
const capture=path.join(base,'builders-oversize-runtime-capture-2873572.jsonl');const rows=fs.readFileSync(capture,'utf8').trim().split('\n').map(JSON.parse);
const wasmPath=path.join(folder,'uplc_tx_bg.wasm');const wasm=fs.readFileSync(wasmPath);const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
let api,imports;
if(target==='node'){api=require(path.join(folder,'uplc_tx.js'));}else{
 const source=fs.readFileSync(path.join(folder,'uplc_tx_bg.js'));const bridge=path.join(base,`builders-oversize-${label}-browser-bindings.mjs`);fs.writeFileSync(bridge,source);api=await import(pathToFileURL(bridge));
 const module=await WebAssembly.compile(wasm);imports=WebAssembly.Module.imports(module);const object={};for(const entry of imports){assert.equal(entry.module,'./uplc_tx_bg.js');assert.equal(typeof api[entry.name],'function');object[entry.module]=api;}
 const instance=await WebAssembly.instantiate(module,object);api.__wbg_set_wasm(instance.exports);instance.exports.__wbindgen_start();
}
const encode=x=>x instanceof Uint8Array?{bytes:Buffer.from(x).toString('hex')}:typeof x==='bigint'?{bigint:String(x)}:Array.isArray(x)?x.map(encode):x;
const decode=x=>Array.isArray(x)?x.map(decode):x&&typeof x==='object'&&'bytes'in x?new Uint8Array(Buffer.from(x.bytes,'hex')):x&&typeof x==='object'&&'bigint'in x?BigInt(x.bigint):x;
const results=[];for(const row of rows){const args=decode(row.args);assert.equal(hash(JSON.stringify(encode(args))),row.requestSha256);let result,error;const start=performance.now();try{result=encode(api.eval_phase_two_raw(...args));}catch(e){error=String(e);}const ms=performance.now()-start;
 assert.deepEqual(result,row.result,`${label}/${target} result ${row.sequence}`);assert.equal(error,row.error,`${label}/${target} error ${row.sequence}`);results.push({sequence:row.sequence,requestSha256:row.requestSha256,ms,result,error});}
const receipt={label,target,wasmSha256:hash(wasm),captureSha256:hash(fs.readFileSync(capture)),requestCount:results.length,exact:true,imports,results};fs.writeFileSync(path.join(base,`builders-oversize-bridge-${label}-${target}.json`),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({...receipt,results:results.filter(r=>[7,8,11,12,22].includes(r.sequence)).map(({result,...r})=>r)},null,2));
