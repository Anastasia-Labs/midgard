use uplc::{ast::{Constant,Type}, builtins::DefaultFunction, machine::{cost_model::*, value::Value, runtime::BuiltinSemantics}};
fn legacy(c: &BuiltinCosts, fun: DefaultFunction, args: &[Value]) -> ExBudget {
 match fun {
 DefaultFunction::FstPair => ExBudget { mem: c.fst_pair.mem.cost(args[0].to_ex_mem()), cpu: c.fst_pair.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::SndPair => ExBudget { mem: c.snd_pair.mem.cost(args[0].to_ex_mem()), cpu: c.snd_pair.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::ChooseList => ExBudget { mem: c.choose_list.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem()), cpu: c.choose_list.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem()) },
 DefaultFunction::MkCons => ExBudget { mem: c.mk_cons.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem()), cpu: c.mk_cons.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem()) },
 DefaultFunction::HeadList => ExBudget { mem: c.head_list.mem.cost(args[0].to_ex_mem()), cpu: c.head_list.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::TailList => ExBudget { mem: c.tail_list.mem.cost(args[0].to_ex_mem()), cpu: c.tail_list.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::NullList => ExBudget { mem: c.null_list.mem.cost(args[0].to_ex_mem()), cpu: c.null_list.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::ChooseData => ExBudget { mem: c.choose_data.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem(), args[3].to_ex_mem(), args[4].to_ex_mem(), args[5].to_ex_mem()), cpu: c.choose_data.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem(), args[3].to_ex_mem(), args[4].to_ex_mem(), args[5].to_ex_mem()) },
 DefaultFunction::ConstrData => ExBudget { mem: c.constr_data.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem()), cpu: c.constr_data.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem()) },
 DefaultFunction::MapData => ExBudget { mem: c.map_data.mem.cost(args[0].to_ex_mem()), cpu: c.map_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::ListData => ExBudget { mem: c.list_data.mem.cost(args[0].to_ex_mem()), cpu: c.list_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::IData => ExBudget { mem: c.i_data.mem.cost(args[0].to_ex_mem()), cpu: c.i_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::BData => ExBudget { mem: c.b_data.mem.cost(args[0].to_ex_mem()), cpu: c.b_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnConstrData => ExBudget { mem: c.un_constr_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_constr_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnMapData => ExBudget { mem: c.un_map_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_map_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnListData => ExBudget { mem: c.un_list_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_list_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnIData => ExBudget { mem: c.un_i_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_i_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnBData => ExBudget { mem: c.un_b_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_b_data.cpu.cost(args[0].to_ex_mem()) },
 _ => panic!("unselected function")
 }
}

fn one_models()->Vec<OneArgument>{vec![OneArgument::ConstantCost(23),OneArgument::LinearCost(LinearSize{intercept:7,slope:3})]}
fn two_models()->Vec<TwoArguments>{vec![
 TwoArguments::ConstantCost(23),TwoArguments::LinearInX(LinearSize{intercept:7,slope:3}),TwoArguments::LinearInY(LinearSize{intercept:7,slope:3}),TwoArguments::LinearInXAndY(TwoVariableLinearSize{intercept:7,slope1:3,slope2:5}),
 TwoArguments::AddedSizes(AddedSizes{intercept:7,slope:3}),TwoArguments::SubtractedSizes(SubtractedSizes{intercept:7,slope:3,minimum:1}),TwoArguments::MultipliedSizes(MultipliedSizes{intercept:7,slope:3}),TwoArguments::MinSize(MinSize{intercept:7,slope:3}),TwoArguments::MaxSize(MaxSize{intercept:7,slope:3}),
 TwoArguments::LinearOnDiagonal(ConstantOrLinear{intercept:7,slope:3,constant:23}),TwoArguments::ConstAboveDiagonal(ConstantOrTwoArguments{constant:23,model:Box::new(TwoArguments::LinearInX(LinearSize{intercept:7,slope:3}))}),TwoArguments::ConstBelowDiagonal(ConstantOrTwoArguments{constant:23,model:Box::new(TwoArguments::LinearInY(LinearSize{intercept:7,slope:3}))}),
 BuiltinCosts::v3().divide_integer.cpu,
]}
fn three_models()->Vec<ThreeArguments>{vec![ThreeArguments::ConstantCost(23),ThreeArguments::AddedSizes(AddedSizes{intercept:7,slope:3}),ThreeArguments::LinearInX(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInY(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInZ(LinearSize{intercept:7,slope:3}),ThreeArguments::LiteralInYorLinearInZ(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInMaxYZ(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInYandZ(TwoVariableLinearSize{intercept:7,slope1:3,slope2:5})]}
fn matrix(){
 let values=[Value::integer(0.into()),Value::list(Type::Data,vec![]),Value::list(Type::Data,(0..64).map(|i|Constant::Data(uplc::ast::Data::integer(i.into()))).collect()),Value::byte_string(vec![1;17])];
 let mut count=0;
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.fst_pair.mem=one_models().remove(model);} if side!=0{c.fst_pair.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::FstPair.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::FstPair,&args).unwrap(),legacy(&c,DefaultFunction::FstPair,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.snd_pair.mem=one_models().remove(model);} if side!=0{c.snd_pair.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::SndPair.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::SndPair,&args).unwrap(),legacy(&c,DefaultFunction::SndPair,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..three_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.choose_list.mem=three_models().remove(model);} if side!=0{c.choose_list.cpu=three_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::ChooseList.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::ChooseList,&args).unwrap(),legacy(&c,DefaultFunction::ChooseList,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..two_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.mk_cons.mem=two_models().remove(model);} if side!=0{c.mk_cons.cpu=two_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::MkCons.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::MkCons,&args).unwrap(),legacy(&c,DefaultFunction::MkCons,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.head_list.mem=one_models().remove(model);} if side!=0{c.head_list.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::HeadList.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::HeadList,&args).unwrap(),legacy(&c,DefaultFunction::HeadList,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.tail_list.mem=one_models().remove(model);} if side!=0{c.tail_list.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::TailList.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::TailList,&args).unwrap(),legacy(&c,DefaultFunction::TailList,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.null_list.mem=one_models().remove(model);} if side!=0{c.null_list.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::NullList.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::NullList,&args).unwrap(),legacy(&c,DefaultFunction::NullList,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..vec![SixArguments::ConstantCost(23)].len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.choose_data.mem=vec![SixArguments::ConstantCost(23)].remove(model);} if side!=0{c.choose_data.cpu=vec![SixArguments::ConstantCost(23)].remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::ChooseData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::ChooseData,&args).unwrap(),legacy(&c,DefaultFunction::ChooseData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..two_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.constr_data.mem=two_models().remove(model);} if side!=0{c.constr_data.cpu=two_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::ConstrData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::ConstrData,&args).unwrap(),legacy(&c,DefaultFunction::ConstrData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.map_data.mem=one_models().remove(model);} if side!=0{c.map_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::MapData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::MapData,&args).unwrap(),legacy(&c,DefaultFunction::MapData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.list_data.mem=one_models().remove(model);} if side!=0{c.list_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::ListData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::ListData,&args).unwrap(),legacy(&c,DefaultFunction::ListData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.i_data.mem=one_models().remove(model);} if side!=0{c.i_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::IData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::IData,&args).unwrap(),legacy(&c,DefaultFunction::IData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.b_data.mem=one_models().remove(model);} if side!=0{c.b_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::BData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::BData,&args).unwrap(),legacy(&c,DefaultFunction::BData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.un_constr_data.mem=one_models().remove(model);} if side!=0{c.un_constr_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::UnConstrData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::UnConstrData,&args).unwrap(),legacy(&c,DefaultFunction::UnConstrData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.un_map_data.mem=one_models().remove(model);} if side!=0{c.un_map_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::UnMapData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::UnMapData,&args).unwrap(),legacy(&c,DefaultFunction::UnMapData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.un_list_data.mem=one_models().remove(model);} if side!=0{c.un_list_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::UnListData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::UnListData,&args).unwrap(),legacy(&c,DefaultFunction::UnListData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.un_i_data.mem=one_models().remove(model);} if side!=0{c.un_i_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::UnIData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::UnIData,&args).unwrap(),legacy(&c,DefaultFunction::UnIData,&args));count+=1;
 }}}}
for language in 0..3 {for model in 0..one_models().len() {for side in 0..3 {
 let mut c=match language{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()};
 if side!=1{c.un_b_data.mem=one_models().remove(model);} if side!=0{c.un_b_data.cpu=one_models().remove(model);}
 for offset in 0..4 {let args=(0..DefaultFunction::UnBData.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::UnBData,&args).unwrap(),legacy(&c,DefaultFunction::UnBData,&args));count+=1;
 }}}}
println!("MATRIX {count} exact comparisons, all publicly constructible enum variants, every selected field, mem/cpu/both");}

fn main(){
 matrix();
 use uplc::ast::{Data,Program,Term,NamedDeBruijn};
 let integer=Constant::Integer(1.into());let bytes=Constant::ByteString(vec![1]);let data=Constant::Data(Data::integer(1.into()));
 let list=Constant::ProtoList(Type::Data,vec![data.clone()]);let empty=Constant::ProtoList(Type::Data,vec![]);
 let pair=Constant::ProtoPair(Type::Data,Type::Data,data.clone().into(),data.clone().into());
 let pairs=Constant::ProtoList(Type::Pair(Type::Data.into(),Type::Data.into()),vec![pair.clone()]);
 let cases=vec![
 (DefaultFunction::FstPair,vec![pair.clone()]),(DefaultFunction::SndPair,vec![pair]),
 (DefaultFunction::ChooseList,vec![list.clone(),integer.clone(),integer.clone()]),(DefaultFunction::MkCons,vec![data.clone(),list.clone()]),
 (DefaultFunction::HeadList,vec![list.clone()]),(DefaultFunction::TailList,vec![list.clone()]),(DefaultFunction::NullList,vec![list.clone()]),
 (DefaultFunction::ChooseData,vec![data.clone(),integer.clone(),integer.clone(),integer.clone(),integer.clone(),integer.clone()]),
 (DefaultFunction::ConstrData,vec![integer.clone(),list.clone()]),(DefaultFunction::MapData,vec![pairs]),(DefaultFunction::ListData,vec![list]),
 (DefaultFunction::IData,vec![integer.clone()]),(DefaultFunction::BData,vec![bytes]),
 (DefaultFunction::UnConstrData,vec![Constant::Data(Data::constr(0,vec![]))]),
 (DefaultFunction::UnMapData,vec![Constant::Data(Data::map(vec![]))]),(DefaultFunction::UnListData,vec![Constant::Data(Data::list(vec![]))]),
 (DefaultFunction::UnIData,vec![data]),(DefaultFunction::UnBData,vec![Constant::Data(Data::bytestring(vec![1]))]),
 ];
 let mut runs=0;
 for (fun,valid) in cases {
  for (kind,args) in [("valid",valid),("integer",vec![integer.clone();fun.arity()]),("empty",vec![empty.clone();fun.arity()])] {
   let mut term:Term<NamedDeBruijn>=Term::Builtin(fun);for _ in 0..fun.force_count(){term=Term::Force(term.into());}
   for arg in args {term=Term::Apply{function:term.into(),argument:Term::Constant(arg.into()).into()};}
   let p=Program{version:(1,1,0),term};let high=p.clone().eval(ExBudget::default());let cost=high.cost();
   if kind=="valid"{assert!(high.result.is_ok(),"{fun:?}: {:?}",high.result);}
   let budgets=[ExBudget::default(),cost,ExBudget{cpu:cost.cpu-1,mem:cost.mem},ExBudget{cpu:cost.cpu,mem:cost.mem-1},ExBudget{cpu:cost.cpu+1,mem:cost.mem+1}];
   for (index,budget) in budgets.into_iter().enumerate(){let result=p.clone().eval(budget);
    if kind=="valid"{assert_eq!(result.result.is_ok(),index==0||index==1||index==4,"{fun:?} {index}");}
    println!("MACHINE {fun:?} {kind} {index} {:?}",result);runs+=1;
   }
  }
 }
 println!("MACHINE_RUNS {runs}");
}
