use uplc::{ast::{Constant,Type}, builtins::DefaultFunction, machine::{cost_model::*, value::Value, runtime::BuiltinSemantics}};
fn legacy(c: &BuiltinCosts, fun: DefaultFunction, args: &[Value]) -> ExBudget {
 match fun {
 DefaultFunction::FstPair => ExBudget { mem: c.fst_pair.mem.cost(args[0].to_ex_mem()), cpu: c.fst_pair.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::SndPair => ExBudget { mem: c.snd_pair.mem.cost(args[0].to_ex_mem()), cpu: c.snd_pair.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::ChooseList => ExBudget { mem: c.choose_list.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem()), cpu: c.choose_list.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem()) },
 DefaultFunction::MkCons => ExBudget { mem: c.mk_cons.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem()), cpu: c.mk_cons.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem()) },
 DefaultFunction::HeadList => ExBudget { mem: c.head_list.mem.cost(args[0].to_ex_mem()), cpu: c.head_list.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::TailList => ExBudget { mem: c.tail_list.mem.cost(args[0].to_ex_mem()), cpu: c.tail_list.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::NullList => ExBudget { mem: c.null_list.mem.cost(args[0].to_ex_mem()), cpu: c.null_list.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::ChooseData => ExBudget { mem: c.choose_data.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem(), args[3].to_ex_mem(), args[4].to_ex_mem(), args[5].to_ex_mem()), cpu: c.choose_data.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem(), args[2].to_ex_mem(), args[3].to_ex_mem(), args[4].to_ex_mem(), args[5].to_ex_mem()) },
 DefaultFunction::ConstrData => ExBudget { mem: c.constr_data.mem.cost(args[0].to_ex_mem(), args[1].to_ex_mem()), cpu: c.constr_data.cpu.cost(args[0].to_ex_mem(), args[1].to_ex_mem()) },
 DefaultFunction::MapData => ExBudget { mem: c.map_data.mem.cost(args[0].to_ex_mem()), cpu: c.map_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::ListData => ExBudget { mem: c.list_data.mem.cost(args[0].to_ex_mem()), cpu: c.list_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::IData => ExBudget { mem: c.i_data.mem.cost(args[0].to_ex_mem()), cpu: c.i_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::BData => ExBudget { mem: c.b_data.mem.cost(args[0].to_ex_mem()), cpu: c.b_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnConstrData => ExBudget { mem: c.un_constr_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_constr_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnMapData => ExBudget { mem: c.un_map_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_map_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnListData => ExBudget { mem: c.un_list_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_list_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnIData => ExBudget { mem: c.un_i_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_i_data.cpu.cost(args[0].to_ex_mem()) },
 DefaultFunction::UnBData => ExBudget { mem: c.un_b_data.mem.cost(args[0].to_ex_mem()), cpu: c.un_b_data.cpu.cost(args[0].to_ex_mem()) },
 _ => panic!("unselected function")
 }
}
fn check() {
 let functions = [
DefaultFunction::FstPair,
DefaultFunction::SndPair,
DefaultFunction::ChooseList,
DefaultFunction::MkCons,
DefaultFunction::HeadList,
DefaultFunction::TailList,
DefaultFunction::NullList,
DefaultFunction::ChooseData,
DefaultFunction::ConstrData,
DefaultFunction::MapData,
DefaultFunction::ListData,
DefaultFunction::IData,
DefaultFunction::BData,
DefaultFunction::UnConstrData,
DefaultFunction::UnMapData,
DefaultFunction::UnListData,
DefaultFunction::UnIData,
DefaultFunction::UnBData,
];
 let values = [
  Value::integer(0.into()),
  Value::list(Type::Data, vec![]),
  Value::list(Type::Data, (0..64).map(|i| Constant::Data(uplc::ast::Data::integer(i.into()))).collect()),
  Value::data(uplc::ast::Data::list((0..64).map(|i| uplc::ast::Data::integer(i.into())).collect())),
 ];
 let mut checks = 0;
 for mut costs in [BuiltinCosts::v1(),BuiltinCosts::v2(),BuiltinCosts::v3()] {
  for variant in 0..3 {
   if variant == 1 {
    costs.head_list.mem=OneArgument::ConstantCost(123456);
    costs.head_list.cpu=OneArgument::ConstantCost(987654);
    costs.choose_data.mem=SixArguments::ConstantCost(76543);
    costs.choose_data.cpu=SixArguments::ConstantCost(23456);
   }
   if variant == 2 {
    costs.head_list.mem=OneArgument::LinearCost(LinearSize{intercept:13,slope:7});
    costs.tail_list.mem=OneArgument::LinearCost(LinearSize{intercept:17,slope:3});
    costs.tail_list.cpu=OneArgument::LinearCost(LinearSize{intercept:19,slope:5});
    costs.mk_cons.mem=TwoArguments::LinearInX(LinearSize{intercept:23,slope:11});
    costs.mk_cons.cpu=TwoArguments::LinearInY(LinearSize{intercept:29,slope:13});
    costs.choose_list.mem=ThreeArguments::LinearInX(LinearSize{intercept:31,slope:17});
    costs.choose_list.cpu=ThreeArguments::LinearInZ(LinearSize{intercept:37,slope:19});
   }
   for fun in functions {
    for value in &values {
     let args=vec![value.clone();fun.arity()];
     assert_eq!(costs.to_ex_budget(fun,&args).unwrap(),legacy(&costs,fun,&args),"{fun:?} variant={variant}");
     checks+=1;
    }
   }
  }
 }
 let costs=BuiltinCosts::v3();
 for fun in [DefaultFunction::HeadList,DefaultFunction::TailList,DefaultFunction::UnListData] {
  let args=vec![Value::integer(0.into())];
  assert_eq!(costs.to_ex_budget(fun,&args).unwrap(),legacy(&costs,fun,&args));
  assert!(fun.call(BuiltinSemantics::V2,&args,&mut vec![]).is_err(),"type errors must survive costing");
 }
 for fun in [DefaultFunction::HeadList,DefaultFunction::TailList] {
  let args=vec![Value::list(Type::Data,vec![])];
  assert_eq!(costs.to_ex_budget(fun,&args).unwrap(),legacy(&costs,fun,&args));
  assert!(fun.call(BuiltinSemantics::V2,&args,&mut vec![]).is_err(),"empty list errors must survive costing");
 }
 for fun in [DefaultFunction::HeadList, DefaultFunction::ChooseData] {
  let args = vec![];
  let new = std::panic::catch_unwind(std::panic::AssertUnwindSafe(||costs.to_ex_budget(fun,&args)));
  let old = std::panic::catch_unwind(std::panic::AssertUnwindSafe(||legacy(&costs,fun,&args)));
  assert!(new.is_err() && old.is_err(), "undersupplied argument behavior must remain identical");
 }
 println!("{checks} exact cost comparisons, 5 runtime type/empty-list refusals and 2 arity checks passed");
}
fn main(){check();}
#[test]
fn constant_cost_equivalence(){check();}
