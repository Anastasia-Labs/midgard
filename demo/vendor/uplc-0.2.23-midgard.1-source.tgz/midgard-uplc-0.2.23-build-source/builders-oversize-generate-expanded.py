from pathlib import Path
import json
base=Path.cwd();old=(base/'builders-oversize-runtime-candidate/src/bin/cost_equivalence.rs').read_text();legacy=old[:old.index('fn check()')]
code=legacy+'''
fn one_models()->Vec<OneArgument>{vec![OneArgument::ConstantCost(23),OneArgument::LinearCost(LinearSize{intercept:7,slope:3})]}
fn two_models()->Vec<TwoArguments>{vec![
 TwoArguments::ConstantCost(23),TwoArguments::LinearInX(LinearSize{intercept:7,slope:3}),TwoArguments::LinearInY(LinearSize{intercept:7,slope:3}),TwoArguments::LinearInXAndY(TwoVariableLinearSize{intercept:7,slope1:3,slope2:5}),
 TwoArguments::AddedSizes(AddedSizes{intercept:7,slope:3}),TwoArguments::SubtractedSizes(SubtractedSizes{intercept:7,slope:3,minimum:1}),TwoArguments::MultipliedSizes(MultipliedSizes{intercept:7,slope:3}),TwoArguments::MinSize(MinSize{intercept:7,slope:3}),TwoArguments::MaxSize(MaxSize{intercept:7,slope:3}),
 TwoArguments::LinearOnDiagonal(ConstantOrLinear{intercept:7,slope:3,constant:23}),TwoArguments::ConstAboveDiagonal(ConstantOrTwoArguments{constant:23,model:Box::new(TwoArguments::LinearInX(LinearSize{intercept:7,slope:3}))}),TwoArguments::ConstBelowDiagonal(ConstantOrTwoArguments{constant:23,model:Box::new(TwoArguments::LinearInY(LinearSize{intercept:7,slope:3}))}),
 BuiltinCosts::v3().divide_integer.cpu,
]}
fn three_models()->Vec<ThreeArguments>{vec![ThreeArguments::ConstantCost(23),ThreeArguments::AddedSizes(AddedSizes{intercept:7,slope:3}),ThreeArguments::LinearInX(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInY(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInZ(LinearSize{intercept:7,slope:3}),ThreeArguments::LiteralInYorLinearInZ(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInMaxYZ(LinearSize{intercept:7,slope:3}),ThreeArguments::LinearInYandZ(TwoVariableLinearSize{intercept:7,slope1:3,slope2:5})]}
fn matrix(){
 let values=[Value::integer(0.into()),Value::list(Type::Data,vec![]),Value::list(Type::Data,(0..64).map(|i|Constant::Data(uplc::ast::Data::integer(i.into()))).collect()),Value::byte_string(vec![1;17])];
 let mut count=0;
'''
for fun,field,typ in json.loads((base/'builders-oversize-cost-targets.json').read_text()):
 models={'OneArgument':'one_models()','TwoArguments':'two_models()','ThreeArguments':'three_models()','SixArguments':'vec![SixArguments::ConstantCost(23)]'}[typ]
 # reconstruct models for two assignment because only some enums clone
 code+=f'''for language in 0..3 {{for model in 0..{models}.len() {{for side in 0..3 {{
 let mut c=match language{{0=>BuiltinCosts::v1(),1=>BuiltinCosts::v2(),_=>BuiltinCosts::v3()}};
 if side!=1{{c.{field}.mem={models}.remove(model);}} if side!=0{{c.{field}.cpu={models}.remove(model);}}
 for offset in 0..4 {{let args=(0..DefaultFunction::{fun}.arity()).map(|i|values[(i+offset)%4].clone()).collect::<Vec<_>>();
 assert_eq!(c.to_ex_budget(DefaultFunction::{fun},&args).unwrap(),legacy(&c,DefaultFunction::{fun},&args));count+=1;
 }}}}}}}}
'''
code+='println!("MATRIX {count} exact comparisons, all publicly constructible enum variants, every selected field, mem/cpu/both");}\n'
code+='''
fn main(){
 matrix();
 use uplc::ast::{Data,Program,Term,NamedDeBruijn};
 let integer=Constant::Integer(1.into());let bytes=Constant::ByteString(vec![1]);let data=Constant::Data(Data::integer(1.into()));
 let list=Constant::ProtoList(Type::Data,vec![data.clone()]);let empty=Constant::ProtoList(Type::Data,vec![]);
 let pair=Constant::ProtoPair(Type::Data,Type::Data,data.clone().into(),data.clone().into());
 let pairs=Constant::ProtoList(Type::Pair(Type::Data.into(),Type::Data.into()),vec![pair.clone()]);
 let cases=vec![
 (DefaultFunction::FstPair,vec![pair.clone()]),(DefaultFunction::SndPair,vec![pair]),
 (DefaultFunction::ChooseList,vec![list.clone(),integer.clone(),integer.clone()]),(DefaultFunction::MkCons,vec![data.clone(),list.clone()]),
 (DefaultFunction::HeadList,vec![list.clone()]),(DefaultFunction::TailList,vec![list.clone()]),(DefaultFunction::NullList,vec![list.clone()]),
 (DefaultFunction::ChooseData,vec![data.clone(),integer.clone(),integer.clone(),integer.clone(),integer.clone(),integer.clone()]),
 (DefaultFunction::ConstrData,vec![integer.clone(),list.clone()]),(DefaultFunction::MapData,vec![pairs]),(DefaultFunction::ListData,vec![list]),
 (DefaultFunction::IData,vec![integer.clone()]),(DefaultFunction::BData,vec![bytes]),
 (DefaultFunction::UnConstrData,vec![Constant::Data(Data::constr(0,vec![]))]),
 (DefaultFunction::UnMapData,vec![Constant::Data(Data::map(vec![]))]),(DefaultFunction::UnListData,vec![Constant::Data(Data::list(vec![]))]),
 (DefaultFunction::UnIData,vec![data]),(DefaultFunction::UnBData,vec![Constant::Data(Data::bytestring(vec![1]))]),
 ];
 let mut runs=0;
 for (fun,valid) in cases {
  for (kind,args) in [("valid",valid),("integer",vec![integer.clone();fun.arity()]),("empty",vec![empty.clone();fun.arity()])] {
   let mut term:Term<NamedDeBruijn>=Term::Builtin(fun);for _ in 0..fun.force_count(){term=Term::Force(term.into());}
   for arg in args {term=Term::Apply{function:term.into(),argument:Term::Constant(arg.into()).into()};}
   let p=Program{version:(1,1,0),term};let high=p.clone().eval(ExBudget::default());let cost=high.cost();
   if kind=="valid"{assert!(high.result.is_ok(),"{fun:?}: {:?}",high.result);}
   let budgets=[ExBudget::default(),cost,ExBudget{cpu:cost.cpu-1,mem:cost.mem},ExBudget{cpu:cost.cpu,mem:cost.mem-1},ExBudget{cpu:cost.cpu+1,mem:cost.mem+1}];
   for (index,budget) in budgets.into_iter().enumerate(){let result=p.clone().eval(budget);
    if kind=="valid"{assert_eq!(result.result.is_ok(),index==0||index==1||index==4,"{fun:?} {index}");}
    println!("MACHINE {fun:?} {kind} {index} {:?}",result);runs+=1;
   }
  }
 }
 println!("MACHINE_RUNS {runs}");
}
'''
for directory in ['builders-oversize-runtime-candidate','builders-oversize-runtime-baseline']:
 p=base/directory/'src/bin/expanded_equivalence.rs';p.parent.mkdir(exist_ok=True);p.write_text(code)
