# Midgard UPLC 0.2.23 build source

This archive accompanies the artifact-only modified npm package. It contains the
unaltered public npm tarball, original uplc 1.1.22 crate, full patched crate, exact
wrapper source and original/patched locks, insertion-only patch, tool identities,
compiler package identities, build scripts, and regression/bridge harnesses.
The wrapper and npm payload derive from Lucid release commit 17fff9d; the UPLC
crate derives from Aiken commit 44fefdd44d252465d693202895a63088bc43fc6c.
The package's MIT license and the UPLC Apache-2.0 license/attributions are retained.

## Exact binary reproduction

Use a fresh environment. Extract this archive's contents under the exact pinned
path `/home/gumbo/midgard-hub/midgard/artifacts/event-history/parallel` (do not
overwrite a working checkout or existing artifacts). Cargo path-package identity
changes code/data ordering when the source path changes, even after file-path
remapping. A relocated build was deliberately tested and differs. A fresh Cargo
target build at the pinned source paths reproduces BOTH final WASM hashes.

Provision the executable versions and hashes in builders-oversize-final-provenance.json:
Rust/cargo 1.97.1, wasm-pack 0.15.0, wasm-bindgen 0.2.100, binaryen wasm-opt 130,
Node 24.13.1 for the binaryen executable. `stable` is a recorded directory name,
not permission to use a different compiler: verify-build-tools.py enforces hashes.
The Rust wasm32-unknown-unknown standard library for that compiler is required.
All registry crates must match the supplied Cargo.lock and be available in Cargo's
cache before the offline build; normal Cargo checksum validation remains enabled.

Download official Ubuntu packages listed in verified-packages.json and
apt-metadata.txt with `apt-get download`, check every SHA256, and extract with
`dpkg-deb -x` into
`builders-oversize-private-clang19/root`. No system install or sudo is needed.
These are Clang 19.1.1, libclang-cpp19, libllvm19, libclang-common-19-dev and
libclang1-19, version 1:19.1.1-1ubuntu1~24.04.2. The build uses a scoped PATH and
LD_LIBRARY_PATH. This compiler differs from the public WASM's Clang 21.1.8;
no bit-identical public-release reproduction is claimed.

From the pinned path, run `bash reproduce.sh`. It verifies tool hashes, builds
nodejs and bundler separately, and checks BOTH final hashes. The two output WASM
modules have different import contracts and must remain paired with their targets.
The cached wasm-opt 117 found during initial exploration was never used; actual
build logs select wasm-opt 130, whose executable identity is pinned.

## Package recipe

Extract upstream-uplc-0.2.23.tgz into builders-oversize-uplc-package. Copy the supplied
Apache license to builders-oversize-runtime-source/UPLC-LICENSE-APACHE-2.0. Run
`python3 builders-oversize-package-final.py` with Python 3.12.3/zlib 1.3. The script
preserves every public member except the two WASM files and adds the license and
modified-source notice. It sorts regular members, writes USTAR with mtime/uid/gid0,
empty owner names, mode0644, and gzip mtime0/empty filename/compression9; it repeats
packaging and asserts identical bytes. The script checks generated JS byte identity
and declarations modulo formatting, retaining original declarations in the package.

## Evidence scope

The six bridge receipts in the external handoff replay the same25 requests against
public, rebuilt baseline and final candidate, for Node and Node-hosted bundler-WASM
bindings. All exact returned redeemer CBOR/units/errors agree. This is not a browser
bundler deployment test. Native expanded tests compare2268 cost evaluations and270
full-machine snapshots across original/candidate. QuadraticInY and QuadraticInZ
constructors have private coefficient fields and are excluded from the external
matrix; their unchanged original fallback code is covered by byte verification.
The original648/5/2 checks also pass after formatting. Protocol limits, costs,
payload shapes and timeouts remain unchanged. Root owns installed acceptance gates.
