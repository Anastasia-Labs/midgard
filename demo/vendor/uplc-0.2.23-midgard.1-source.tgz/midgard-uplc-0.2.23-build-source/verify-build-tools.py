from pathlib import Path
import hashlib,json
p=json.loads(Path('builders-oversize-final-provenance.json').read_text())
for name,entry in p['tools'].items():
 actual=hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest()
 assert actual==entry['sha256'], (name,actual,entry['sha256'])
print('All recorded tool executable identities match')
