from pathlib import Path
import tarfile,gzip,io,hashlib,base64,json,shutil,subprocess,re
base=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
original=base/'builders-oversize-uplc-package/package';stage=base/'builders-oversize-uplc-final-package/package';shutil.copytree(original,stage,dirs_exist_ok=True)
for target,folder in [('node','pkg'),('browser','pkg-browser')]:
 generated=base/'builders-oversize-runtime-candidate'/folder
 for p in (original/'dist'/target).iterdir():
  if p.suffix=='.js':assert p.read_bytes()==(generated/p.name).read_bytes(),p
  elif p.name.endswith('.d.ts'):
   normalize=lambda x:re.sub(r',(?=[)\]])','',re.sub(r'\s+','',x))
   assert normalize(p.read_text())==normalize((generated/p.name).read_text()),p
 shutil.copy2(generated/'uplc_tx_bg.wasm',stage/'dist'/target/'uplc_tx_bg.wasm')
shutil.copy2(base/'builders-oversize-runtime-source/UPLC-LICENSE-APACHE-2.0',stage/'LICENSE-UPLC-APACHE-2.0')
(stage/'NOTICE-MIDGARD-UPLC.txt').write_text('''This is an artifact-local modified build of @lucid-evolution/uplc 0.2.23.
The original wrapper JavaScript, declarations, README, package metadata and MIT
LICENSE are unchanged from the public npm package. No external publication is
implied. The two dist/node and dist/browser uplc_tx_bg.wasm files are modified.

The WASM includes Aiken UPLC 1.1.22 (Apache-2.0), source commit
44fefdd44d252465d693202895a63088bc43fc6c. Copyright notices and the Apache license
are reproduced in LICENSE-UPLC-APACHE-2.0. Midgard's local modification inserts
lazy constant-cost accounting for 18 builtins in src/machine/cost_model.rs;
nonconstant accounting and runtime execution remain unchanged. The exact patch,
original crate, wrapper source/lock, compiler provenance and build recipe are
provided in the accompanying midgard-uplc-0.2.23-build-source archive. The modified
source file is identified by that patch and this notice. Rebuilt with Rust 1.97.1,
Clang 19.1.1 and wasm-opt 130; this is not a bit-identical upstream release build.
''')
def archive(directory,destination,root):
 out=io.BytesIO()
 with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
   for p in sorted(directory.rglob('*')):
    if not p.is_file():continue
    data=p.read_bytes();info=tarfile.TarInfo(str(Path(root)/p.relative_to(directory)));info.size=len(data);info.mode=0o644;info.uid=info.gid=0;info.mtime=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(data))
 data=out.getvalue();destination.write_bytes(data);return {'file':destination.name,'bytes':len(data),'sha256':sha(data),'sha512':hashlib.sha512(data).hexdigest(),'integrity':'sha512-'+base64.b64encode(hashlib.sha512(data).digest()).decode()}
package=archive(stage,base/'builders-midgard-uplc-0.2.23-constant-cost.tgz','package')
receipt={'package':package,'members':[], 'unchangedPublishedMembers':[], 'modifiedPublishedMembers':[]}
for p in sorted(stage.rglob('*')):
 if p.is_file():
  name=str(p.relative_to(stage));receipt['members'].append({'path':'package/'+name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
  prior=original/name
  if prior.exists():receipt['unchangedPublishedMembers' if prior.read_bytes()==p.read_bytes() else 'modifiedPublishedMembers'].append(name)
assert receipt['modifiedPublishedMembers']==['dist/browser/uplc_tx_bg.wasm','dist/node/uplc_tx_bg.wasm']
assert len(receipt['unchangedPublishedMembers'])==10
assert len(receipt['members'])==14
# Repeat archive to establish deterministic packaging in this Python/zlib toolchain.
repeat=base/'builders-midgard-uplc-0.2.23-constant-cost-repeat.tgz';assert archive(stage,repeat,'package')['sha256']==package['sha256'];repeat.unlink()
(base/'builders-oversize-package-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(package,indent=2))
