#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
nodebin=/home/gumbo/.nvm/versions/node/v22.22.2/bin/node
for target in node browser; do
 "$nodebin" builders-oversize-bridge.mjs published "$target" "$PWD/builders-oversize-uplc-package/package/dist/$target" > "builders-oversize-bridge-published-$target.log" 2>&1
 folder=pkg
 if [ "$target" = browser ]; then folder=pkg-browser; fi
 for label in baseline candidate; do
  "$nodebin" builders-oversize-bridge.mjs "$label" "$target" "$PWD/builders-oversize-runtime-$label/$folder" > "builders-oversize-bridge-$label-$target.log" 2>&1
 done
done
