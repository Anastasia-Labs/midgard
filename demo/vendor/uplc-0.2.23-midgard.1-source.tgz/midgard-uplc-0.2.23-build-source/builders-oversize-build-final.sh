#!/usr/bin/env bash
set -euo pipefail
base=$(cd "$(dirname "$0")" && pwd)
export PATH="$base/builders-oversize-private-clang19/root/usr/lib/llvm-19/bin:/home/gumbo/.nvm/versions/node/v24.13.1/bin:$PATH"
export LD_LIBRARY_PATH="$base/builders-oversize-private-clang19/root/usr/lib/x86_64-linux-gnu"
export CARGO_TARGET_DIR="${EVALUATOR_TARGET_DIR:-$base/builders-oversize-runtime-build-target}"
export CARGO_NET_OFFLINE=true
wrapper=$1
crate=$2
export RUSTFLAGS="--remap-path-prefix=$wrapper=/midgard-evaluator/wrapper --remap-path-prefix=$crate=/midgard-evaluator/uplc --remap-path-prefix=/home/gumbo/.cargo/registry=/cargo/registry"
cd "$wrapper"
wasm-pack build --mode no-install --target nodejs --release --out-dir pkg --locked --offline
wasm-pack build --mode no-install --target bundler --release --out-dir pkg-browser --locked --offline
