#!/usr/bin/env bash
set -euo pipefail
expected=/home/gumbo/midgard-hub/midgard/artifacts/event-history/parallel
if [ "$PWD" != "$expected" ]; then
 echo "Exact-WASM recipe requires pinned source path: $expected" >&2
 exit 1
fi
python3 verify-build-tools.py
export PATH="/home/gumbo/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/home/gumbo/.cargo/bin:$PATH"
export EVALUATOR_TARGET_DIR="$PWD/builders-oversize-clean-build-target"
bash builders-oversize-build-final.sh "$PWD/builders-oversize-runtime-candidate" "$PWD/builders-oversize-uplc-candidate"
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json
p=json.loads(Path('builders-oversize-final-provenance.json').read_text())
for target,folder in [('node','pkg'),('browser','pkg-browser')]:
 assert hashlib.sha256(Path('builders-oversize-runtime-candidate',folder,'uplc_tx_bg.wasm').read_bytes()).hexdigest()==p['wasm'][target]['final']
print('Both WASM binaries match frozen identities')
CHECK
