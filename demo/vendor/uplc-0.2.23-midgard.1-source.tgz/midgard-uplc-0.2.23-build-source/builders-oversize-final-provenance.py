from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil,platform,zlib
b=Path(__file__).resolve().parent; sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
crate=Path('/home/gumbo/.cargo/registry/cache/index.crates.io-1949cf8c6b5b557f/uplc-1.1.22.crate');changed=[];checks=[]
with tarfile.open(crate) as t:
 for m in t.getmembers():
  if not m.isfile():continue
  rel=Path(m.name).relative_to('uplc-1.1.22');p=b/'builders-oversize-uplc-candidate'/rel;old=t.extractfile(m).read();checks.append({'path':str(rel),'originalSha256':hashlib.sha256(old).hexdigest(),'candidateSha256':sha(p)})
  if old!=p.read_bytes():changed.append(str(rel))
assert changed==['src/machine/cost_model.rs'];assert len(checks)==42
cm=b/'builders-oversize-uplc-candidate/src/machine/cost_model.rs';s=cm.read_text();a=s.index('        // Constant cost models');end=s.index('        Ok(match fun {',a)
with tarfile.open(crate) as t:assert (s[:a]+s[end:]).encode()==t.extractfile('uplc-1.1.22/src/machine/cost_model.rs').read()
checksums={}
for target,folder in [('node','pkg'),('browser','pkg-browser')]:
 primary=b/'builders-oversize-runtime-candidate'/folder/'uplc_tx_bg.wasm';first=b/'builders-oversize-formatted-first'/folder/'uplc_tx_bg.wasm';relocated=b/'builders-oversize-reproduction/builders-oversize-runtime-candidate'/folder/'uplc_tx_bg.wasm'
 assert primary.read_bytes()==first.read_bytes();checksums[target]={'final':sha(primary),'cleanTargetRebuild':sha(first),'relocatedSource':sha(relocated),'bytes':primary.stat().st_size}
tools={}
paths={'rustc':subprocess.check_output(['rustup','which','rustc'],text=True).strip(),'cargo':subprocess.check_output(['rustup','which','cargo'],text=True).strip(),'wasm-pack':'/home/gumbo/.cargo/bin/wasm-pack','wasm-bindgen':'/home/gumbo/.cache/.wasm-pack/wasm-bindgen-baa57e3e202e624b/wasm-bindgen','wasm-opt':'/home/gumbo/.nvm/versions/node/v24.13.1/lib/node_modules/binaryen/bin/wasm-opt','node-build':'/home/gumbo/.nvm/versions/node/v24.13.1/bin/node','node-test':'/home/gumbo/.nvm/versions/node/v22.22.2/bin/node','clang':str(b/'builders-oversize-private-clang19/root/usr/lib/llvm-19/bin/clang')}
for name,path in paths.items():tools[name]={'path':path,'sha256':sha(Path(path))}
receipts=[]
for target in ['node','browser']:
 for label in ['published','baseline','candidate']:
  p=b/f'builders-oversize-bridge-{label}-{target}.json';d=json.loads(p.read_text());assert d['exact'] and d['requestCount']==25;receipts.append({'path':p.name,'sha256':sha(p),'wasmSha256':d['wasmSha256']})
x=b/'builders-oversize-expanded-baseline.stdout';y=b/'builders-oversize-expanded-candidate.stdout';assert x.read_bytes()==y.read_bytes()
result={'crateSha256':sha(crate),'crateVcsCommit':'44fefdd44d252465d693202895a63088bc43fc6c','sourceFilesChecked':checks,'onlyChangedFile':changed,'originalOutsideInsertionIdentical':True,'patchSha256':sha(b/'builders-oversize-constant-cost-final.patch'),'wrapperOriginalLockSha256':sha(b/'builders-oversize-runtime-baseline/Cargo.lock'),'wrapperPatchedLockSha256':sha(b/'builders-oversize-runtime-candidate/Cargo.lock'),'wasm':checksums,'tools':tools,'compilerVersions':{'rustc':'1.97.1 (8bab26f4f 2026-07-14)','cargo':'1.97.1 (c980f4866 2026-06-30)','clang':'19.1.1','publishedClang':'21.1.8','wasm-pack':'0.15.0','wasm-bindgen':'0.2.100','wasm-opt':'130','unusedCachedWasmOpt':'117','nodeBuild':'24.13.1','nodeEvaluation':'22.22.2','python':platform.python_version(),'zlib':zlib.ZLIB_VERSION},'bridges':receipts,'expandedNativeSnapshotSha256':sha(x),'expandedCostComparisons':2268,'fullMachineComparisons':270,'originalCostComparisons':648,'originalRuntimeRefusals':5,'originalArityChecks':2}
(b/'builders-oversize-final-provenance.json').write_text(json.dumps(result,indent=2)+'\n')
